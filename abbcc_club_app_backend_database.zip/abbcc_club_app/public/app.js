const app = document.getElementById("app");
const statusPill = document.getElementById("statusPill");

const LEVELS = {
  coach: ["Sans diplôme", "Brevet Fédéral", "DETB"],
  player: ["U9", "U11", "U13", "U15", "U18", "U20", "Seniors"]
};

const FUNDAMENTALS = {
  Tir: ["Gestuelle", "Appuis", "Précision"],
  Passe: ["Précision", "Timing", "Choix de passe"],
  Dribble: ["Contrôle", "Main faible", "Changement de rythme"],
  Défense: ["Placement", "Attitude", "Réactivité"],
  Physique: ["Vitesse", "Endurance", "Coordination"]
};

const state = {
  user: null,
  activePage: ""
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "include",
    ...options,
    headers: options.body instanceof FormData
      ? options.headers || {}
      : { "Content-Type": "application/json", ...(options.headers || {}) }
  });

  const text = await response.text();
  let data = {};

  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    throw new Error(data.error || "Erreur serveur.");
  }

  return data;
}

function escapeHtml(text) {
  return String(text ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(value) {
  if (!value) return "-";
  return new Date(value).toLocaleString("fr-FR");
}

function formatAverage(value) {
  return Number(value || 0).toFixed(2).replace(".", ",");
}

function badgeStatus(status) {
  if (status === "Validé") return `<span class="badge green">Validé</span>`;
  if (status === "Refusé") return `<span class="badge red">Refusé</span>`;
  if (status === "Terminée") return `<span class="badge green">Terminée</span>`;
  if (status === "À faire") return `<span class="badge yellow">À faire</span>`;
  return `<span class="badge yellow">En attente</span>`;
}

function roleLabel(role) {
  if (role === "coach") return "Coach";
  if (role === "player") return "Joueur";
  return "Admin";
}

function setStatus(text) {
  statusPill.innerHTML = `Statut : <strong>${escapeHtml(text)}</strong>`;
}

function showMessage(id, message, type = "ok") {
  const node = document.getElementById(id);
  if (!node) return;

  node.textContent = message;
  node.className = `message ${type}`;

  setTimeout(() => {
    node.textContent = "";
    node.className = "message";
  }, 4500);
}

async function init() {
  try {
    const data = await api("/api/auth/me");
    state.user = data.user;
    routeByRole();
  } catch {
    state.user = null;
    renderHome();
  }
}

function renderHome() {
  setStatus("déconnecté");
  app.innerHTML = `
    <section class="grid">
      <div class="card">
        <h2 class="hero-title">Bienvenue au club</h2>
        <p class="hint">Connecte-toi pour accéder à ton espace. Si tu es nouveau, fais une demande d’inscription coach ou joueur.</p>
        <div class="actions">
          <button class="success" onclick="renderRegister()">Créer une inscription</button>
        </div>
      </div>

      <div class="card">
        <h2>Connexion au site</h2>
        <p class="hint">Admin : identifiant admin. Coach ou joueur validé : email + mot de passe.</p>

        <form id="loginForm">
          <label>Identifiant ou email</label>
          <input id="loginIdentifier" required autocomplete="username" />

          <label>Mot de passe</label>
          <input id="loginPassword" type="password" required autocomplete="current-password" />

          <div class="actions">
            <button type="submit">Se connecter</button>
            <button type="button" class="secondary" onclick="renderRegister()">S’inscrire</button>
          </div>

          <div id="loginMessage" class="message"></div>
        </form>
      </div>
    </section>
  `;

  document.getElementById("loginForm").addEventListener("submit", async event => {
    event.preventDefault();

    try {
      const data = await api("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({
          identifier: document.getElementById("loginIdentifier").value,
          password: document.getElementById("loginPassword").value
        })
      });

      state.user = data.user;
      routeByRole();
    } catch (error) {
      showMessage("loginMessage", error.message, "error");
    }
  });
}

function renderRegister() {
  setStatus("inscription");
  app.innerHTML = `
    <section class="card">
      <h2>Demande d’inscription</h2>
      <p class="hint">L’inscription sera active après validation par l’admin.</p>

      <form id="registerForm">
        <label>Je veux m’inscrire comme</label>
        <div class="role-choice">
          <label>
            <input type="radio" name="role" value="coach" checked />
            <span class="role-box">🧢 <strong>Coach</strong><br><small>Encadrer, organiser, entraîner.</small></span>
          </label>
          <label>
            <input type="radio" name="role" value="player" />
            <span class="role-box">🏃 <strong>Joueur</strong><br><small>Rejoindre une équipe et progresser.</small></span>
          </label>
        </div>

        <div class="grid">
          <div>
            <label>Nom complet</label>
            <input name="name" required />
          </div>
          <div>
            <label>Email</label>
            <input name="email" type="email" required />
          </div>
        </div>

        <div class="grid">
          <div>
            <label>Téléphone</label>
            <input name="phone" />
          </div>
          <div>
            <label>Âge</label>
            <input name="age" type="number" min="6" max="99" />
          </div>
        </div>

        <label id="levelLabel">Diplôme du coach</label>
        <select name="level" id="levelSelect" required></select>

        <div class="grid">
          <div>
            <label>Mot de passe</label>
            <input name="password" type="password" minlength="6" required />
          </div>
          <div>
            <label>Confirmer le mot de passe</label>
            <input name="passwordConfirm" type="password" minlength="6" required />
          </div>
        </div>

        <label>Message / motivation</label>
        <textarea name="message"></textarea>

        <div class="actions">
          <button class="success" type="submit">Envoyer la demande</button>
          <button type="button" class="secondary" onclick="renderHome()">Retour connexion</button>
        </div>

        <div id="registerMessage" class="message"></div>
      </form>
    </section>
  `;

  const form = document.getElementById("registerForm");
  const levelSelect = document.getElementById("levelSelect");
  const levelLabel = document.getElementById("levelLabel");

  function updateLevels() {
    const role = new FormData(form).get("role");
    levelLabel.textContent = role === "coach" ? "Diplôme du coach" : "Catégorie du joueur";
    levelSelect.innerHTML = LEVELS[role].map(item => `<option>${escapeHtml(item)}</option>`).join("");
  }

  form.querySelectorAll("[name='role']").forEach(input => input.addEventListener("change", updateLevels));
  updateLevels();

  form.addEventListener("submit", async event => {
    event.preventDefault();

    const formData = new FormData(form);
    if (formData.get("password") !== formData.get("passwordConfirm")) {
      showMessage("registerMessage", "Les mots de passe ne correspondent pas.", "error");
      return;
    }

    try {
      await api("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(Object.fromEntries(formData.entries()))
      });
      form.reset();
      updateLevels();
      showMessage("registerMessage", "Demande envoyée. Elle est en attente de validation admin.", "ok");
    } catch (error) {
      showMessage("registerMessage", error.message, "error");
    }
  });
}

function routeByRole() {
  if (!state.user) return renderHome();

  if (state.user.role === "admin") {
    renderAdmin();
  } else if (state.user.role === "coach") {
    renderCoach();
  } else {
    renderPlayer();
  }
}

async function logout() {
  await api("/api/auth/logout", { method: "POST" });
  state.user = null;
  renderHome();
}

function renderShell(title, hint, tabs) {
  app.innerHTML = `
    <section class="card">
      <div class="grid">
        <div>
          <h2>${escapeHtml(title)}</h2>
          <p class="hint">${escapeHtml(hint)}</p>
        </div>
        <div style="text-align:right">
          <button class="secondary" onclick="logout()">Déconnexion</button>
        </div>
      </div>

      <div class="tabs">
        ${tabs.map(tab => `<button class="tab secondary" data-page="${tab.id}" onclick="${tab.handler}">${escapeHtml(tab.label)}</button>`).join("")}
      </div>

      <div id="content"></div>
    </section>
  `;
}

function markActive(page) {
  document.querySelectorAll("[data-page]").forEach(button => {
    button.classList.toggle("active", button.dataset.page === page);
  });
  state.activePage = page;
}

function content(html) {
  document.getElementById("content").innerHTML = html;
}

function renderAdmin() {
  setStatus("admin connecté");
  renderShell("Espace admin", "Validation, listes, exercices, équipes et évaluations.", [
    { id: "validation", label: "Validation", handler: "adminValidation()" },
    { id: "players", label: "Joueurs", handler: "adminUsers('player')" },
    { id: "coaches", label: "Coachs", handler: "adminUsers('coach')" },
    { id: "exercises", label: "Exercices", handler: "adminExercises()" },
    { id: "teams", label: "Équipes", handler: "adminTeams()" },
    { id: "evaluations", label: "Évaluations", handler: "adminEvaluations()" }
  ]);
  adminValidation();
}

async function adminValidation() {
  markActive("validation");
  const data = await api("/api/admin/users");
  content(`
    <h3>Demandes d’inscription</h3>
    <div class="actions">
      <a href="/api/admin/export.csv"><button class="secondary">Exporter CSV</button></a>
    </div>
    ${usersTable(data.users, true)}
  `);
}

async function adminUsers(role) {
  markActive(role === "player" ? "players" : "coaches");
  const data = await api(`/api/admin/users?role=${role}`);
  content(`<h3>${role === "player" ? "Joueurs" : "Coachs"}</h3>${usersTable(data.users, true)}`);
}

function usersTable(users, withActions) {
  if (!users.length) return `<div class="empty">Aucun compte.</div>`;

  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Statut</th><th>Rôle</th><th>Nom</th><th>Email</th><th>Téléphone</th><th>Âge</th><th>Niveau</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(user => `
            <tr>
              <td>${badgeStatus(user.status)}</td>
              <td>${roleLabel(user.role)}</td>
              <td>${escapeHtml(user.name)}</td>
              <td>${escapeHtml(user.email)}</td>
              <td>${escapeHtml(user.phone || "-")}</td>
              <td>${escapeHtml(user.age || "-")}</td>
              <td>${escapeHtml(user.level || "-")}</td>
              <td>
                ${withActions ? `
                  <div class="actions">
                    <button class="success mini" onclick="adminSetStatus('${user.id}','Validé')">Valider</button>
                    <button class="warning mini" onclick="adminSetStatus('${user.id}','En attente')">Attente</button>
                    <button class="danger mini" onclick="adminSetStatus('${user.id}','Refusé')">Refuser</button>
                    <button class="danger mini" onclick="adminDeleteUser('${user.id}')">Supprimer</button>
                  </div>
                ` : ""}
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `;
}

async function adminSetStatus(id, status) {
  await api(`/api/admin/users/${id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status })
  });
  adminValidation();
}

async function adminDeleteUser(id) {
  if (!confirm("Supprimer ce compte ?")) return;
  await api(`/api/admin/users/${id}`, { method: "DELETE" });
  adminValidation();
}

async function adminExercises() {
  markActive("exercises");
  const data = await api("/api/admin/exercises");
  content(`<h3>Exercices partagés</h3>${exerciseList(data.exercises, "admin")}`);
}

async function adminTeams() {
  markActive("teams");
  const data = await api("/api/admin/teams");
  content(`<h3>Équipes</h3>${teamList(data.teams, "admin")}`);
}

async function adminEvaluations() {
  markActive("evaluations");
  const [requests, evaluations] = await Promise.all([
    api("/api/admin/evaluation-requests"),
    api("/api/admin/evaluations")
  ]);

  content(`
    <h3>Demandes d’évaluation</h3>
    ${requests.requests.length ? requests.requests.map(request => `
      <div class="soft-card">
        <h3>${escapeHtml(request.player_name)} ${badgeStatus(request.status)}</h3>
        <p class="hint">Coach : ${escapeHtml(request.coach_name)} · Équipe : ${escapeHtml(request.team_name || "-")} · ${formatDate(request.created_at)}</p>
        <p>${escapeHtml(request.phrase || "")}</p>
        <button class="danger mini" onclick="adminDeleteRequest('${request.id}')">Supprimer</button>
      </div>
    `).join("") : `<div class="empty">Aucune demande.</div>`}

    <h3>Évaluations terminées</h3>
    ${evaluations.evaluations.length ? evaluations.evaluations.map(evaluation => renderEvaluationCard(evaluation, true, "admin")).join("") : `<div class="empty">Aucune évaluation.</div>`}
  `);
}

async function adminDeleteRequest(id) {
  if (!confirm("Supprimer cette demande ?")) return;
  await api(`/api/admin/evaluation-requests/${id}`, { method: "DELETE" });
  adminEvaluations();
}

async function adminDeleteEvaluation(id) {
  if (!confirm("Supprimer cette évaluation ?")) return;
  await api(`/api/admin/evaluations/${id}`, { method: "DELETE" });
  adminEvaluations();
}

async function adminDeleteExercise(id) {
  if (!confirm("Supprimer cet exercice ?")) return;
  await api(`/api/admin/exercises/${id}`, { method: "DELETE" });
  adminExercises();
}

async function adminDeleteTeam(id) {
  if (!confirm("Supprimer cette équipe ?")) return;
  await api(`/api/admin/teams/${id}`, { method: "DELETE" });
  adminTeams();
}

function renderCoach() {
  setStatus("coach connecté");
  renderShell("Espace coach", "Profil, joueurs inscrits, exercices partagés, équipes et évaluations.", [
    { id: "profile", label: "Profil", handler: "coachProfile()" },
    { id: "players", label: "Joueurs inscrits", handler: "coachPlayers()" },
    { id: "exercises", label: "Partage d’exercices", handler: "coachExercises()" },
    { id: "teams", label: "Équipes", handler: "coachTeams()" },
    { id: "evaluations", label: "Évaluations", handler: "coachEvaluations()" }
  ]);
  coachProfile();
}

async function coachProfile() {
  markActive("profile");
  const data = await api("/api/coach/profile");
  const user = data.user;

  content(`
    <h3>Modifier mon profil coach</h3>
    <form id="coachProfileForm">
      <div class="grid">
        <div>
          <label>Email</label>
          <input name="email" type="email" value="${escapeHtml(user.email)}" required />
        </div>
        <div>
          <label>Téléphone</label>
          <input name="phone" value="${escapeHtml(user.phone || "")}" />
        </div>
      </div>

      <label>Diplôme</label>
      <select name="level">
        ${LEVELS.coach.map(level => `<option ${user.level === level ? "selected" : ""}>${escapeHtml(level)}</option>`).join("")}
      </select>

      <div class="actions">
        <button class="success">Enregistrer</button>
      </div>

      <div id="coachProfileMessage" class="message"></div>
    </form>
  `);

  document.getElementById("coachProfileForm").addEventListener("submit", async event => {
    event.preventDefault();

    try {
      const formData = new FormData(event.target);
      const updated = await api("/api/coach/profile", {
        method: "PATCH",
        body: JSON.stringify(Object.fromEntries(formData.entries()))
      });
      state.user = updated.user;
      showMessage("coachProfileMessage", "Profil mis à jour.", "ok");
    } catch (error) {
      showMessage("coachProfileMessage", error.message, "error");
    }
  });
}

async function coachPlayers() {
  markActive("players");
  const data = await api("/api/coach/players");

  content(`
    <h3>Joueurs inscrits</h3>
    <p class="hint">Clique sur un joueur pour voir son profil et toutes ses évaluations.</p>
    ${playersTable(data.players)}
    <div id="coachPlayerDetails"></div>
  `);
}

function playersTable(players) {
  if (!players.length) return `<div class="empty">Aucun joueur inscrit.</div>`;

  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Statut</th><th>Nom</th><th>Email</th><th>Téléphone</th><th>Âge</th><th>Catégorie</th><th>Accès</th>
          </tr>
        </thead>
        <tbody>
          ${players.map(player => `
            <tr>
              <td>${badgeStatus(player.status)}</td>
              <td>${escapeHtml(player.name)}</td>
              <td>${escapeHtml(player.email)}</td>
              <td>${escapeHtml(player.phone || "-")}</td>
              <td>${escapeHtml(player.age || "-")}</td>
              <td>${escapeHtml(player.level || "-")}</td>
              <td><button class="success mini" onclick="coachPlayerDetails('${player.id}')">Voir le joueur</button></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `;
}

async function coachPlayerDetails(playerId) {
  const data = await api(`/api/coach/players/${playerId}/evaluations`);
  const player = data.player;

  document.getElementById("coachPlayerDetails").innerHTML = `
    <div class="soft-card">
      <h3>${escapeHtml(player.name)}</h3>
      <div class="profile-box">
        <div class="profile-item"><span>Email</span><strong>${escapeHtml(player.email)}</strong></div>
        <div class="profile-item"><span>Téléphone</span><strong>${escapeHtml(player.phone || "-")}</strong></div>
        <div class="profile-item"><span>Âge</span><strong>${escapeHtml(player.age || "-")}</strong></div>
        <div class="profile-item"><span>Catégorie</span><strong>${escapeHtml(player.level || "-")}</strong></div>
      </div>
      <h3>Évaluations</h3>
      ${data.evaluations.length ? data.evaluations.map(evaluation => renderEvaluationCard(evaluation, false)).join("") : `<div class="empty">Aucune évaluation.</div>`}
    </div>
  `;

  document.getElementById("coachPlayerDetails").scrollIntoView({ behavior: "smooth" });
}

async function coachExercises() {
  markActive("exercises");
  const data = await api("/api/coach/exercises");

  content(`
    <h3>Bibliothèque d’exercices des coachs</h3>
    <p class="hint">Les exercices sont partagés entre tous les coachs validés.</p>

    <form id="exerciseForm" class="soft-card">
      <div class="grid">
        <div>
          <label>Titre</label>
          <input name="title" required />
        </div>
        <div>
          <label>Fichier</label>
          <input name="file" type="file" required />
        </div>
      </div>
      <label>Description</label>
      <textarea name="description"></textarea>
      <div class="actions">
        <button class="success">Partager</button>
      </div>
      <div id="exerciseMessage" class="message"></div>
    </form>

    ${exerciseList(data.exercises, "coach")}
  `);

  document.getElementById("exerciseForm").addEventListener("submit", async event => {
    event.preventDefault();

    try {
      const formData = new FormData(event.target);
      await api("/api/coach/exercises", { method: "POST", body: formData });
      coachExercises();
    } catch (error) {
      showMessage("exerciseMessage", error.message, "error");
    }
  });
}

function exerciseList(exercises, mode) {
  if (!exercises.length) return `<div class="empty">Aucun exercice partagé.</div>`;

  return exercises.map(exercise => `
    <div class="soft-card">
      <h3>${escapeHtml(exercise.title)}</h3>
      <p class="hint">${escapeHtml(exercise.description || "Aucune description.")}</p>
      <p><span class="badge blue">Coach : ${escapeHtml(exercise.coach_name)}</span><span class="badge yellow">${formatDate(exercise.created_at)}</span></p>
      <p><a href="${exercise.url}" download="${escapeHtml(exercise.file_name)}">Télécharger : ${escapeHtml(exercise.file_name)}</a></p>
      ${
        mode === "admin"
          ? `<button class="danger mini" onclick="adminDeleteExercise('${exercise.id}')">Supprimer</button>`
          : exercise.coach_id === state.user.id
            ? `<button class="danger mini" onclick="coachDeleteExercise('${exercise.id}')">Supprimer mon exercice</button>`
            : ""
      }
    </div>
  `).join("");
}

async function coachDeleteExercise(id) {
  if (!confirm("Supprimer cet exercice ?")) return;
  await api(`/api/coach/exercises/${id}`, { method: "DELETE" });
  coachExercises();
}

async function coachTeams() {
  markActive("teams");
  const [players, teams] = await Promise.all([
    api("/api/coach/players"),
    api("/api/coach/teams")
  ]);

  const validPlayers = players.players.filter(player => player.status === "Validé");

  content(`
    <h3>Créer une équipe</h3>
    <form id="teamForm" class="soft-card">
      <label>Nom de l’équipe</label>
      <input name="name" required />

      <div class="check-list">
        ${validPlayers.map(player => `
          <label class="check-item">
            <input type="checkbox" name="playerIds" value="${player.id}" />
            <span><strong>${escapeHtml(player.name)}</strong><br><small>${escapeHtml(player.level || "")}</small></span>
          </label>
        `).join("") || `<div class="empty">Aucun joueur validé.</div>`}
      </div>

      <div class="actions">
        <button class="success">Créer l’équipe</button>
      </div>
      <div id="teamMessage" class="message"></div>
    </form>

    <h3>Mes équipes</h3>
    ${teamList(teams.teams, "coach")}
  `);

  document.getElementById("teamForm").addEventListener("submit", async event => {
    event.preventDefault();

    const formData = new FormData(event.target);
    const playerIds = formData.getAll("playerIds");

    try {
      await api("/api/coach/teams", {
        method: "POST",
        body: JSON.stringify({
          name: formData.get("name"),
          playerIds
        })
      });
      coachTeams();
    } catch (error) {
      showMessage("teamMessage", error.message, "error");
    }
  });
}

function teamList(teams, mode) {
  if (!teams.length) return `<div class="empty">Aucune équipe.</div>`;

  return teams.map(team => `
    <div class="soft-card">
      <h3>${escapeHtml(team.name)}</h3>
      <p class="hint">Coach : ${escapeHtml(team.coach_name)} · ${formatDate(team.created_at)}</p>
      <p>${team.players.map(player => `<span class="badge green">${escapeHtml(player.name)} · ${escapeHtml(player.level || "")}</span>`).join("")}</p>
      ${
        mode === "admin"
          ? `<button class="danger mini" onclick="adminDeleteTeam('${team.id}')">Supprimer</button>`
          : `
            <label>Phrase / objectif de l’évaluation</label>
            <textarea id="teamPhrase_${team.id}" placeholder="Évaluation des fondamentaux..."></textarea>
            <div class="actions">
              <button class="success mini" onclick="coachLaunchEvaluation('${team.id}')">Lancer une évaluation</button>
              <button class="danger mini" onclick="coachDeleteTeam('${team.id}')">Supprimer l’équipe</button>
            </div>
          `
      }
    </div>
  `).join("");
}

async function coachDeleteTeam(id) {
  if (!confirm("Supprimer cette équipe ?")) return;
  await api(`/api/coach/teams/${id}`, { method: "DELETE" });
  coachTeams();
}

async function coachLaunchEvaluation(teamId) {
  const phrase = document.getElementById(`teamPhrase_${teamId}`).value;
  await api(`/api/coach/teams/${teamId}/evaluation-requests`, {
    method: "POST",
    body: JSON.stringify({ phrase })
  });
  alert("Demandes d’évaluation créées.");
  coachEvaluations();
}

async function coachEvaluations() {
  markActive("evaluations");
  const [requests, evaluations] = await Promise.all([
    api("/api/coach/evaluation-requests"),
    api("/api/coach/evaluations")
  ]);

  content(`
    <h3>Demandes d’évaluation</h3>
    ${requests.requests.length ? requests.requests.map(request => requestCard(request)).join("") : `<div class="empty">Aucune demande.</div>`}
    <h3>Évaluations terminées</h3>
    ${evaluations.evaluations.length ? evaluations.evaluations.map(evaluation => renderEvaluationCard(evaluation, false)).join("") : `<div class="empty">Aucune évaluation.</div>`}
  `);
}

function requestCard(request) {
  return `
    <div class="soft-card">
      <h3>${escapeHtml(request.player_name)} ${badgeStatus(request.status)}</h3>
      <p class="hint">Équipe : ${escapeHtml(request.team_name || "-")} · ${formatDate(request.created_at)}</p>
      <p>${escapeHtml(request.phrase || "")}</p>
      ${request.status === "À faire" ? `<button class="success mini" onclick="openEvaluationForm('${request.id}')">Remplir l’évaluation</button><div id="evalForm_${request.id}"></div>` : ""}
    </div>
  `;
}

function openEvaluationForm(requestId) {
  const container = document.getElementById(`evalForm_${requestId}`);
  let html = `<form class="soft-card" id="form_${requestId}"><p class="hint">Notes de 1 à 10. Tu peux ajouter des sous-parties dans chaque fondamental.</p>`;

  Object.entries(FUNDAMENTALS).forEach(([fundamental, criteria], index) => {
    html += `
      <div class="soft-card" data-fundamental-block="${escapeHtml(fundamental)}">
        <h3>${escapeHtml(fundamental)}</h3>
        <div class="criteria-grid" id="criteria_${requestId}_${index}">
          ${criteria.map(name => criteriaInput(fundamental, name)).join("")}
        </div>
        <label>Ajouter une sous-partie</label>
        <div class="grid">
          <input id="newCriteria_${requestId}_${index}" placeholder="Ex : lecture du jeu, équilibre..." />
          <button type="button" class="secondary" onclick="addCriteria('${requestId}', ${index}, '${escapeHtml(fundamental)}')">Ajouter</button>
        </div>
        <label>Commentaire ${escapeHtml(fundamental)}</label>
        <textarea name="comment_${escapeHtml(fundamental)}"></textarea>
      </div>
    `;
  });

  html += `<div class="actions"><button class="success">Enregistrer l’évaluation</button></div></form>`;
  container.innerHTML = html;

  document.getElementById(`form_${requestId}`).addEventListener("submit", async event => {
    event.preventDefault();
    await saveEvaluation(requestId, event.target);
  });
}

function criteriaInput(fundamental, name) {
  return `
    <div>
      <label>${escapeHtml(name)}</label>
      <select data-fundamental="${escapeHtml(fundamental)}" data-criteria="${escapeHtml(name)}">
        ${Array.from({ length: 10 }, (_, i) => {
          const value = i + 1;
          const label = value === 1 ? "1 · Débutant" : value === 5 ? "5 · Intermédiaire" : value === 10 ? "10 · Confirmé" : String(value);
          return `<option value="${value}">${label}</option>`;
        }).join("")}
      </select>
    </div>
  `;
}

function addCriteria(requestId, index, fundamental) {
  const input = document.getElementById(`newCriteria_${requestId}_${index}`);
  const grid = document.getElementById(`criteria_${requestId}_${index}`);
  const name = input.value.trim();

  if (!name) return alert("Ajoute un nom de sous-partie.");

  const wrapper = document.createElement("div");
  wrapper.innerHTML = criteriaInput(fundamental, name);
  grid.appendChild(wrapper.firstElementChild);
  input.value = "";
}

async function saveEvaluation(requestId, form) {
  const fundamentals = {};

  form.querySelectorAll("select[data-fundamental]").forEach(select => {
    const fundamental = select.dataset.fundamental;
    if (!fundamentals[fundamental]) {
      fundamentals[fundamental] = { criteria: [], comment: form.elements[`comment_${fundamental}`]?.value || "" };
    }
    fundamentals[fundamental].criteria.push({
      name: select.dataset.criteria,
      score: Number(select.value)
    });
  });

  await api(`/api/coach/evaluation-requests/${requestId}/evaluations`, {
    method: "POST",
    body: JSON.stringify({ fundamentals })
  });

  coachEvaluations();
}

function renderPlayer() {
  setStatus("joueur connecté");
  renderShell("Espace joueur", "Profil et évaluations.", [
    { id: "profile", label: "Profil", handler: "playerProfile()" },
    { id: "evaluations", label: "Mes évaluations", handler: "playerEvaluations()" }
  ]);
  playerProfile();
}

async function playerProfile() {
  markActive("profile");
  const data = await api("/api/player/profile");
  const user = data.user;

  content(`
    <h3>Mon profil</h3>
    <div class="profile-box">
      <div class="profile-item"><span>Nom</span><strong>${escapeHtml(user.name)}</strong></div>
      <div class="profile-item"><span>Email</span><strong>${escapeHtml(user.email)}</strong></div>
      <div class="profile-item"><span>Téléphone</span><strong>${escapeHtml(user.phone || "-")}</strong></div>
      <div class="profile-item"><span>Catégorie</span><strong>${escapeHtml(user.level || "-")}</strong></div>
    </div>
  `);
}

async function playerEvaluations() {
  markActive("evaluations");
  const data = await api("/api/player/evaluations");

  content(`
    <h3>Mes évaluations</h3>
    <p class="hint">Vue simple avec graphique en étoile. Clique sur une note de fondamental pour voir les sous-parties.</p>
    ${data.evaluations.length ? data.evaluations.map((evaluation, index) => renderPlayerEvaluation(evaluation, index)).join("") : `<div class="empty">Aucune évaluation.</div>`}
  `);

  data.evaluations.forEach((evaluation, index) => {
    drawRadar(`radar_${index}_${evaluation.id}`, radarValues(evaluation), evaluation.scale || 10);
  });
}

function renderPlayerEvaluation(evaluation, index) {
  const radarId = `radar_${index}_${evaluation.id}`;
  const scale = evaluation.scale || 10;

  const notes = Object.entries(FUNDAMENTALS).map(([fundamental], i) => {
    const item = evaluation.fundamentals[fundamental];
    const detailId = `detail_${index}_${i}_${evaluation.id}`;
    return `<button class="fundamental-note" onclick="toggleDetail('${detailId}', this)">${escapeHtml(fundamental)} : ${formatAverage(item ? item.average : 0)}/${scale}</button>`;
  }).join("");

  const details = Object.entries(FUNDAMENTALS).map(([fundamental], i) => {
    const item = evaluation.fundamentals[fundamental];
    const detailId = `detail_${index}_${i}_${evaluation.id}`;
    if (!item) return "";
    return `
      <div class="soft-card fundamental-detail" id="${detailId}">
        <h3>Détail ${escapeHtml(fundamental)}</h3>
        <p>${Object.entries(item.criteria).map(([name, score]) => `<span class="badge yellow">${escapeHtml(name)} : ${score}/${scale}</span>`).join("")}</p>
        <p class="hint">${escapeHtml(item.comment || "Aucun commentaire.")}</p>
      </div>
    `;
  }).join("");

  const comments = Object.entries(evaluation.fundamentals)
    .map(([fundamental, item]) => item.comment ? `<div class="soft-card"><h3>${escapeHtml(fundamental)}</h3><p class="hint">${escapeHtml(item.comment)}</p></div>` : "")
    .join("");

  return `
    <div class="soft-card">
      <h3>Évaluation du ${formatDate(evaluation.created_at)}</h3>
      <p class="hint">Coach : ${escapeHtml(evaluation.coach_name || "-")}</p>

      <div class="radar-layout">
        <div class="radar-box"><canvas class="radar-canvas" id="${radarId}" width="320" height="320"></canvas></div>
        <div>
          <div class="score-box"><span>Note globale</span><strong>${evaluation.score100}/100</strong></div>
          <p class="hint">${escapeHtml(evaluation.phrase || "")}</p>
          <div>${notes}</div>
        </div>
      </div>

      ${details}

      <h3>Commentaires du résultat</h3>
      ${comments || `<div class="empty">Aucun commentaire.</div>`}
    </div>
  `;
}

function toggleDetail(id, button) {
  const node = document.getElementById(id);
  if (!node) return;

  node.classList.toggle("active");
  button.classList.toggle("active");
}

function radarValues(evaluation) {
  return Object.keys(FUNDAMENTALS).map(name => Number(evaluation.fundamentals[name]?.average || 0));
}

function drawRadar(canvasId, values, maxValue = 10) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) * 0.33;
  const labels = Object.keys(FUNDAMENTALS);

  ctx.clearRect(0, 0, width, height);
  ctx.font = "14px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  for (let level = 1; level <= maxValue; level++) {
    const r = radius * (level / maxValue);
    ctx.beginPath();
    labels.forEach((label, index) => {
      const angle = -Math.PI / 2 + Math.PI * 2 * index / labels.length;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      index === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.strokeStyle = level === maxValue ? "rgba(255,255,255,.28)" : "rgba(255,255,255,.13)";
    ctx.stroke();
  }

  labels.forEach((label, index) => {
    const angle = -Math.PI / 2 + Math.PI * 2 * index / labels.length;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius);
    ctx.strokeStyle = "rgba(255,255,255,.22)";
    ctx.stroke();
    ctx.fillStyle = "#f8fafc";
    ctx.fillText(label, cx + Math.cos(angle) * (radius + 28), cy + Math.sin(angle) * (radius + 28));
  });

  ctx.beginPath();
  values.forEach((value, index) => {
    const normalized = Math.max(0, Math.min(maxValue, value)) / maxValue;
    const angle = -Math.PI / 2 + Math.PI * 2 * index / labels.length;
    const x = cx + Math.cos(angle) * radius * normalized;
    const y = cy + Math.sin(angle) * radius * normalized;
    index === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.closePath();
  ctx.fillStyle = "rgba(249,115,22,.30)";
  ctx.strokeStyle = "rgba(249,115,22,.95)";
  ctx.lineWidth = 3;
  ctx.fill();
  ctx.stroke();

  values.forEach((value, index) => {
    const normalized = Math.max(0, Math.min(maxValue, value)) / maxValue;
    const angle = -Math.PI / 2 + Math.PI * 2 * index / labels.length;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(angle) * radius * normalized, cy + Math.sin(angle) * radius * normalized, 4, 0, Math.PI * 2);
    ctx.fillStyle = "#22c55e";
    ctx.fill();
  });
}

function renderEvaluationCard(evaluation, allowDelete, mode = "") {
  const scale = evaluation.scale || 10;

  const details = Object.entries(evaluation.fundamentals).map(([fundamental, item]) => `
    <div class="soft-card">
      <h3>${escapeHtml(fundamental)} · ${formatAverage(item.average)}/${scale}</h3>
      <p>${Object.entries(item.criteria).map(([name, score]) => `<span class="badge yellow">${escapeHtml(name)} : ${score}/${scale}</span>`).join("")}</p>
      <p class="hint">${escapeHtml(item.comment || "Aucun commentaire.")}</p>
    </div>
  `).join("");

  return `
    <div class="soft-card">
      <h3>${escapeHtml(evaluation.player_name || "Joueur")} · Note ${evaluation.score100}/100</h3>
      <p class="hint">Coach : ${escapeHtml(evaluation.coach_name || "-")} · ${formatDate(evaluation.created_at)}</p>
      <p>${escapeHtml(evaluation.phrase || "")}</p>
      ${details}
      ${allowDelete && mode === "admin" ? `<button class="danger mini" onclick="adminDeleteEvaluation('${evaluation.id}')">Supprimer</button>` : ""}
    </div>
  `;
}

init();
