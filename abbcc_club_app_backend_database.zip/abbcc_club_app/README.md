# Amical BRIANT Basket Club Coulogne

Application web complète avec :

- Backend Node.js / Express
- Base de données SQLite
- Connexion admin, coach et joueur
- Validation des inscriptions par l’admin
- Exercices partagés entre coachs validés
- Upload et téléchargement de fichiers d’exercices
- Équipes créées par les coachs
- Demandes d’évaluation
- Évaluations sur 10 avec sous-parties personnalisables
- Note joueur sur 100
- Graphique radar / étoile côté joueur
- Suppressions côté admin

## Installation locale

1. Installer Node.js version 20 ou plus.
2. Ouvrir un terminal dans ce dossier.
3. Installer les dépendances :

```bash
npm install
```

4. Lancer le site :

```bash
npm start
```

5. Ouvrir :

```text
http://localhost:3000
```

## Identifiant admin local

Le fichier `.env` inclus crée l’admin automatiquement au premier lancement.

Identifiant :

```text
chretien.c
```

Mot de passe : celui configuré dans `.env`.

Avant une vraie mise en ligne, change impérativement :

```text
ADMIN_PASSWORD
SESSION_SECRET
COOKIE_SECURE=true
NODE_ENV=production
```

## Où sont les données ?

La base de données est créée ici :

```text
data/club.sqlite
```

Les fichiers d’exercices sont stockés ici :

```text
uploads/
```

## Mise en ligne

Cette application nécessite un hébergement qui accepte Node.js, par exemple :

- un VPS
- Render
- Railway
- Fly.io
- un serveur personnel

Il faut installer les dépendances, configurer les variables d’environnement, puis lancer :

```bash
npm start
```

## Important

Ne mets jamais le fichier `.env` public sur GitHub.

Pour un hébergement sérieux, configure les variables d’environnement directement dans la plateforme d’hébergement.
