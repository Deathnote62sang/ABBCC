@echo off
title Amical BRIANT Basket Club Coulogne
cd /d "%~dp0"

echo.
echo =========================================
echo  Amical BRIANT Basket Club Coulogne
echo =========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERREUR : Node.js n'est pas installe.
  echo Installe Node.js puis relance ce fichier.
  pause
  exit /b
)

if not exist "node_modules" (
  echo Installation des dependances...
  npm install
)

echo.
echo Demarrage du site...
echo Garde cette fenetre ouverte.
echo.
start http://localhost:3000
npm start

pause
