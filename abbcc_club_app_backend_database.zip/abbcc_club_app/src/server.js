const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const Database = require("better-sqlite3");

const app = express();

const ROOT_DIR = path.join(__dirname, "..");
const PUBLIC_DIR = path.join(ROOT_DIR, "public");
const DATA_DIR = path.join(ROOT_DIR, "data");
const UPLOADS_DIR = path.join(ROOT_DIR, "uploads");
const DB_PATH = path.join(DATA_DIR, "club.sqlite");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma("foreign_keys = ON");

const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || "dev-secret-change-me";
const COOKIE_SECURE = String(process.env.COOKIE_SECURE || "false").toLowerCase() === "true";

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use("/uploads", express.static(UPLOADS_DIR));
app.use(express.static(PUBLIC_DIR));

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "");
      cb(null, crypto.randomUUID() + ext);
    }
  }),
  limits: {
    fileSize: 20 * 1024 * 1024
  }
});

function createSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      role TEXT NOT NULL CHECK(role IN ('admin', 'coach', 'player')),
      username TEXT UNIQUE,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      age INTEGER,
      level TEXT,
      status TEXT NOT NULL DEFAULT 'En attente' CHECK(status IN ('En attente', 'Validé', 'Refusé')),
      enroll_message TEXT,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      validated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS exercises (
      id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      description TEXT,
      file_name TEXT NOT NULL,
      mime_type TEXT,
      file_path TEXT NOT NULL,
      file_size INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS teams (
      id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS team_players (
      team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
      player_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      PRIMARY KEY (team_id, player_id)
    );

    CREATE TABLE IF NOT EXISTS evaluation_requests (
      id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      team_id TEXT REFERENCES teams(id) ON DELETE SET NULL,
      player_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      phrase TEXT,
      status TEXT NOT NULL DEFAULT 'À faire' CHECK(status IN ('À faire', 'Terminée')),
      created_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS evaluations (
      id TEXT PRIMARY KEY,
      request_id TEXT REFERENCES evaluation_requests(id) ON DELETE SET NULL,
      coach_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      team_id TEXT REFERENCES teams(id) ON DELETE SET NULL,
      player_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      phrase TEXT,
      scale INTEGER NOT NULL DEFAULT 10,
      global_average REAL NOT NULL,
      score100 INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS evaluation_fundamentals (
      id TEXT PRIMARY KEY,
      evaluation_id TEXT NOT NULL REFERENCES evaluations(id) ON DELETE CASCADE,
      fundamental TEXT NOT NULL,
      comment TEXT,
      average REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS evaluation_criteria (
      id TEXT PRIMARY KEY,
      fundamental_id TEXT NOT NULL REFERENCES evaluation_fundamentals(id) ON DELETE CASCADE,
      criteria TEXT NOT NULL,
      score INTEGER NOT NULL
    );
  `);
}

function now() {
  return new Date().toISOString();
}

function id() {
  return crypto.randomUUID();
}

function hashPassword(password) {
  return bcrypt.hashSync(password, 12);
}

function verifyPassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

function seedAdmin() {
  const adminUsername = process.env.ADMIN_USERNAME || "chretien.c";
  const adminEmail = process.env.ADMIN_EMAIL || "admin@abbcc.local";
  const adminPassword = process.env.ADMIN_PASSWORD || "ChangeMoiAvantMiseEnLigne";

  const existing = db.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();
  if (existing) return;

  db.prepare(`
    INSERT INTO users (
      id, role, username, name, email, phone, age, level, status, enroll_message,
      password_hash, created_at, updated_at, validated_at
    )
    VALUES (?, 'admin', ?, 'Administrateur', ?, '', NULL, '', 'Validé', '',
      ?, ?, ?, ?)
  `).run(id(), adminUsername, adminEmail, hashPassword(adminPassword), now(), now(), now());
}

createSchema();
seedAdmin();

function base64url(input) {
  return Buffer.from(input).toString("base64url");
}

function signToken(payload) {
  const body = base64url(JSON.stringify(payload));
  const signature = crypto
    .createHmac("sha256", SESSION_SECRET)
    .update(body)
    .digest("base64url");

  return `${body}.${signature}`;
}

function verifyToken(token) {
  if (!token || !token.includes(".")) return null;

  const [body, signature] = token.split(".");
  const expected = crypto
    .createHmac("sha256", SESSION_SECRET)
    .update(body)
    .digest("base64url");

  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return null;
  }

  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf-8"));
  if (payload.exp && Date.now() > payload.exp) return null;

  return payload;
}

function setSessionCookie(res, user) {
  const token = signToken({
    userId: user.id,
    role: user.role,
    exp: Date.now() + 1000 * 60 * 60 * 12
  });

  res.cookie("abbcc_session", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: COOKIE_SECURE,
    maxAge: 1000 * 60 * 60 * 12
  });
}

function clearSessionCookie(res) {
  res.clearCookie("abbcc_session");
}

function safeUser(user) {
  if (!user) return null;

  return {
    id: user.id,
    role: user.role,
    username: user.username,
    name: user.name,
    email: user.email,
    phone: user.phone,
    age: user.age,
    level: user.level,
    status: user.status,
    enroll_message: user.enroll_message,
    created_at: user.created_at,
    updated_at: user.updated_at,
    validated_at: user.validated_at
  };
}

function auth(req, res, next) {
  const payload = verifyToken(req.cookies.abbcc_session);
  if (!payload) {
    return res.status(401).json({ error: "Connexion requise." });
  }

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(payload.userId);
  if (!user) {
    return res.status(401).json({ error: "Compte introuvable." });
  }

  req.user = user;
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Accès refusé." });
    }

    next();
  };
}

function requireValidatedMember(req, res, next) {
  if (req.user.role === "admin") return next();

  if (req.user.status !== "Validé") {
    return res.status(403).json({ error: "Compte non validé." });
  }

  next();
}

function exerciseRow(row) {
  return {
    id: row.id,
    coach_id: row.coach_id,
    coach_name: row.coach_name,
    title: row.title,
    description: row.description,
    file_name: row.file_name,
    mime_type: row.mime_type,
    file_size: row.file_size,
    url: `/uploads/${path.basename(row.file_path)}`,
    created_at: row.created_at
  };
}

function getEvaluationById(evaluationId) {
  const evaluation = db.prepare(`
    SELECT e.*, p.name AS player_name, c.name AS coach_name
    FROM evaluations e
    JOIN users p ON p.id = e.player_id
    JOIN users c ON c.id = e.coach_id
    WHERE e.id = ?
  `).get(evaluationId);

  if (!evaluation) return null;

  const fundamentalsRows = db.prepare(`
    SELECT * FROM evaluation_fundamentals WHERE evaluation_id = ? ORDER BY rowid
  `).all(evaluation.id);

  const fundamentals = {};

  for (const fundamental of fundamentalsRows) {
    const criteriaRows = db.prepare(`
      SELECT criteria, score FROM evaluation_criteria WHERE fundamental_id = ? ORDER BY rowid
    `).all(fundamental.id);

    const criteria = {};
    for (const row of criteriaRows) {
      criteria[row.criteria] = row.score;
    }

    fundamentals[fundamental.fundamental] = {
      average: fundamental.average,
      comment: fundamental.comment,
      criteria
    };
  }

  return {
    id: evaluation.id,
    request_id: evaluation.request_id,
    coach_id: evaluation.coach_id,
    coach_name: evaluation.coach_name,
    team_id: evaluation.team_id,
    player_id: evaluation.player_id,
    player_name: evaluation.player_name,
    phrase: evaluation.phrase,
    scale: evaluation.scale,
    globalAverage: evaluation.global_average,
    score100: evaluation.score100,
    created_at: evaluation.created_at,
    fundamentals
  };
}

function listEvaluations(whereSql = "", params = []) {
  const rows = db.prepare(`
    SELECT e.id
    FROM evaluations e
    ${whereSql}
    ORDER BY e.created_at DESC
  `).all(...params);

  return rows.map(row => getEvaluationById(row.id));
}

function getTeam(teamId) {
  const team = db.prepare(`
    SELECT t.*, u.name AS coach_name
    FROM teams t
    JOIN users u ON u.id = t.coach_id
    WHERE t.id = ?
  `).get(teamId);

  if (!team) return null;

  const players = db.prepare(`
    SELECT u.id, u.name, u.email, u.phone, u.age, u.level, u.status
    FROM team_players tp
    JOIN users u ON u.id = tp.player_id
    WHERE tp.team_id = ?
    ORDER BY u.name
  `).all(teamId).map(safeUser);

  return {
    id: team.id,
    coach_id: team.coach_id,
    coach_name: team.coach_name,
    name: team.name,
    created_at: team.created_at,
    players
  };
}

function listTeams(whereSql = "", params = []) {
  const rows = db.prepare(`
    SELECT id FROM teams ${whereSql} ORDER BY created_at DESC
  `).all(...params);

  return rows.map(row => getTeam(row.id));
}

app.post("/api/auth/register", (req, res) => {
  const { role, name, email, phone, age, level, password, message } = req.body;

  if (!["coach", "player"].includes(role)) {
    return res.status(400).json({ error: "Rôle invalide." });
  }

  if (!name || !email || !password || !level) {
    return res.status(400).json({ error: "Nom, email, mot de passe et niveau sont obligatoires." });
  }

  if (String(password).length < 6) {
    return res.status(400).json({ error: "Le mot de passe doit contenir au moins 6 caractères." });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(normalizedEmail);
  if (existing) {
    return res.status(409).json({ error: "Cet email est déjà inscrit." });
  }

  const userId = id();

  db.prepare(`
    INSERT INTO users (
      id, role, username, name, email, phone, age, level, status, enroll_message,
      password_hash, created_at, updated_at, validated_at
    )
    VALUES (?, ?, NULL, ?, ?, ?, ?, ?, 'En attente', ?, ?, ?, ?, NULL)
  `).run(
    userId,
    role,
    String(name).trim(),
    normalizedEmail,
    phone || "",
    age ? Number(age) : null,
    level,
    message || "",
    hashPassword(password),
    now(),
    now()
  );

  res.status(201).json({ message: "Demande d’inscription envoyée." });
});

app.post("/api/auth/login", (req, res) => {
  const { identifier, password } = req.body;

  if (!identifier || !password) {
    return res.status(400).json({ error: "Identifiant/email et mot de passe obligatoires." });
  }

  const normalized = String(identifier).trim().toLowerCase();

  const user = db.prepare(`
    SELECT * FROM users
    WHERE lower(email) = ? OR lower(username) = ?
    LIMIT 1
  `).get(normalized, normalized);

  if (!user || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: "Identifiant ou mot de passe incorrect." });
  }

  if (user.role !== "admin" && user.status !== "Validé") {
    return res.status(403).json({
      error: user.status === "Refusé"
        ? "Cette inscription a été refusée."
        : "Cette inscription est encore en attente de validation admin."
    });
  }

  setSessionCookie(res, user);
  res.json({ user: safeUser(user) });
});

app.post("/api/auth/logout", (req, res) => {
  clearSessionCookie(res);
  res.json({ message: "Déconnecté." });
});

app.get("/api/auth/me", auth, (req, res) => {
  res.json({ user: safeUser(req.user) });
});

app.get("/api/admin/users", auth, requireRole("admin"), (req, res) => {
  const { role, status } = req.query;

  let sql = "SELECT * FROM users WHERE role != 'admin'";
  const params = [];

  if (role) {
    sql += " AND role = ?";
    params.push(role);
  }

  if (status) {
    sql += " AND status = ?";
    params.push(status);
  }

  sql += " ORDER BY created_at DESC";

  const users = db.prepare(sql).all(...params).map(safeUser);
  res.json({ users });
});

app.patch("/api/admin/users/:id/status", auth, requireRole("admin"), (req, res) => {
  const { status } = req.body;
  if (!["En attente", "Validé", "Refusé"].includes(status)) {
    return res.status(400).json({ error: "Statut invalide." });
  }

  const user = db.prepare("SELECT * FROM users WHERE id = ? AND role != 'admin'").get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: "Compte introuvable." });
  }

  db.prepare(`
    UPDATE users
    SET status = ?, updated_at = ?, validated_at = CASE WHEN ? = 'Validé' THEN ? ELSE validated_at END
    WHERE id = ?
  `).run(status, now(), status, now(), req.params.id);

  res.json({ user: safeUser(db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id)) });
});

app.delete("/api/admin/users/:id", auth, requireRole("admin"), (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ? AND role != 'admin'").get(req.params.id);
  if (!user) return res.status(404).json({ error: "Compte introuvable." });

  const files = db.prepare("SELECT file_path FROM exercises WHERE coach_id = ?").all(req.params.id);
  db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);

  for (const file of files) {
    try {
      fs.unlinkSync(file.file_path);
    } catch {}
  }

  res.json({ message: "Compte supprimé." });
});

app.get("/api/admin/exercises", auth, requireRole("admin"), (req, res) => {
  const rows = db.prepare(`
    SELECT e.*, u.name AS coach_name
    FROM exercises e
    JOIN users u ON u.id = e.coach_id
    ORDER BY e.created_at DESC
  `).all();

  res.json({ exercises: rows.map(exerciseRow) });
});

app.delete("/api/admin/exercises/:id", auth, requireRole("admin"), (req, res) => {
  const exercise = db.prepare("SELECT * FROM exercises WHERE id = ?").get(req.params.id);
  if (!exercise) return res.status(404).json({ error: "Exercice introuvable." });

  db.prepare("DELETE FROM exercises WHERE id = ?").run(req.params.id);
  try { fs.unlinkSync(exercise.file_path); } catch {}

  res.json({ message: "Exercice supprimé." });
});

app.get("/api/admin/teams", auth, requireRole("admin"), (req, res) => {
  res.json({ teams: listTeams() });
});

app.delete("/api/admin/teams/:id", auth, requireRole("admin"), (req, res) => {
  db.prepare("DELETE FROM teams WHERE id = ?").run(req.params.id);
  res.json({ message: "Équipe supprimée." });
});

app.get("/api/admin/evaluation-requests", auth, requireRole("admin"), (req, res) => {
  const rows = db.prepare(`
    SELECT er.*, c.name AS coach_name, p.name AS player_name, t.name AS team_name
    FROM evaluation_requests er
    JOIN users c ON c.id = er.coach_id
    JOIN users p ON p.id = er.player_id
    LEFT JOIN teams t ON t.id = er.team_id
    ORDER BY er.created_at DESC
  `).all();

  res.json({ requests: rows });
});

app.delete("/api/admin/evaluation-requests/:id", auth, requireRole("admin"), (req, res) => {
  db.prepare("DELETE FROM evaluation_requests WHERE id = ?").run(req.params.id);
  res.json({ message: "Demande supprimée." });
});

app.get("/api/admin/evaluations", auth, requireRole("admin"), (req, res) => {
  res.json({ evaluations: listEvaluations() });
});

app.delete("/api/admin/evaluations/:id", auth, requireRole("admin"), (req, res) => {
  db.prepare("DELETE FROM evaluations WHERE id = ?").run(req.params.id);
  res.json({ message: "Évaluation supprimée." });
});

app.get("/api/admin/export.csv", auth, requireRole("admin"), (req, res) => {
  const users = db.prepare("SELECT * FROM users WHERE role != 'admin' ORDER BY created_at DESC").all();

  const headers = ["Date", "Statut", "Role", "Nom", "Email", "Telephone", "Age", "Niveau", "Message"];
  const rows = users.map(user => [
    user.created_at,
    user.status,
    user.role,
    user.name,
    user.email,
    user.phone || "",
    user.age || "",
    user.level || "",
    user.enroll_message || ""
  ]);

  const csv = [headers, ...rows]
    .map(row => row.map(value => `"${String(value ?? "").replaceAll('"', '""')}"`).join(";"))
    .join("\n");

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=demandes_inscription_abbcc.csv");
  res.send("\ufeff" + csv);
});

app.get("/api/coach/profile", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  res.json({ user: safeUser(req.user) });
});

app.patch("/api/coach/profile", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const { email, phone, level } = req.body;

  if (!email || !level) {
    return res.status(400).json({ error: "Email et diplôme obligatoires." });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const existing = db.prepare("SELECT id FROM users WHERE email = ? AND id != ?").get(normalizedEmail, req.user.id);

  if (existing) {
    return res.status(409).json({ error: "Cet email est déjà utilisé." });
  }

  db.prepare(`
    UPDATE users SET email = ?, phone = ?, level = ?, updated_at = ? WHERE id = ?
  `).run(normalizedEmail, phone || "", level, now(), req.user.id);

  res.json({ user: safeUser(db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id)) });
});

app.get("/api/coach/players", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const players = db.prepare(`
    SELECT * FROM users WHERE role = 'player' ORDER BY
      CASE status WHEN 'Validé' THEN 1 WHEN 'En attente' THEN 2 ELSE 3 END,
      name ASC
  `).all().map(safeUser);

  res.json({ players });
});

app.get("/api/coach/players/:id/evaluations", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const player = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'player'").get(req.params.id);
  if (!player) return res.status(404).json({ error: "Joueur introuvable." });

  res.json({ player: safeUser(player), evaluations: listEvaluations("WHERE e.player_id = ?", [req.params.id]) });
});

app.get("/api/coach/exercises", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const rows = db.prepare(`
    SELECT e.*, u.name AS coach_name
    FROM exercises e
    JOIN users u ON u.id = e.coach_id
    WHERE u.role = 'coach' AND u.status = 'Validé'
    ORDER BY e.created_at DESC
  `).all();

  res.json({ exercises: rows.map(exerciseRow) });
});

app.post("/api/coach/exercises", auth, requireRole("coach"), requireValidatedMember, upload.single("file"), (req, res) => {
  const { title, description } = req.body;

  if (!title || !req.file) {
    return res.status(400).json({ error: "Titre et fichier obligatoires." });
  }

  const exerciseId = id();
  db.prepare(`
    INSERT INTO exercises (
      id, coach_id, title, description, file_name, mime_type, file_path, file_size, created_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    exerciseId,
    req.user.id,
    title,
    description || "",
    req.file.originalname,
    req.file.mimetype,
    req.file.path,
    req.file.size,
    now()
  );

  const row = db.prepare(`
    SELECT e.*, u.name AS coach_name
    FROM exercises e
    JOIN users u ON u.id = e.coach_id
    WHERE e.id = ?
  `).get(exerciseId);

  res.status(201).json({ exercise: exerciseRow(row) });
});

app.delete("/api/coach/exercises/:id", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const exercise = db.prepare("SELECT * FROM exercises WHERE id = ? AND coach_id = ?").get(req.params.id, req.user.id);
  if (!exercise) return res.status(404).json({ error: "Exercice introuvable ou non autorisé." });

  db.prepare("DELETE FROM exercises WHERE id = ?").run(req.params.id);
  try { fs.unlinkSync(exercise.file_path); } catch {}

  res.json({ message: "Exercice supprimé." });
});

app.get("/api/coach/teams", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  res.json({ teams: listTeams("WHERE coach_id = ?", [req.user.id]) });
});

app.post("/api/coach/teams", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const { name, playerIds } = req.body;

  if (!name || !Array.isArray(playerIds) || playerIds.length === 0) {
    return res.status(400).json({ error: "Nom d’équipe et joueurs obligatoires." });
  }

  const validPlayers = db.prepare(`
    SELECT id FROM users WHERE role = 'player' AND status = 'Validé'
  `).all().map(row => row.id);

  const selected = [...new Set(playerIds)].filter(playerId => validPlayers.includes(playerId));
  if (selected.length === 0) {
    return res.status(400).json({ error: "Aucun joueur validé sélectionné." });
  }

  const teamId = id();
  const tx = db.transaction(() => {
    db.prepare("INSERT INTO teams (id, coach_id, name, created_at) VALUES (?, ?, ?, ?)")
      .run(teamId, req.user.id, name, now());

    const insertPlayer = db.prepare("INSERT INTO team_players (team_id, player_id) VALUES (?, ?)");
    for (const playerId of selected) {
      insertPlayer.run(teamId, playerId);
    }
  });

  tx();

  res.status(201).json({ team: getTeam(teamId) });
});

app.delete("/api/coach/teams/:id", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const team = db.prepare("SELECT * FROM teams WHERE id = ? AND coach_id = ?").get(req.params.id, req.user.id);
  if (!team) return res.status(404).json({ error: "Équipe introuvable ou non autorisée." });

  db.prepare("DELETE FROM teams WHERE id = ?").run(req.params.id);
  res.json({ message: "Équipe supprimée." });
});

app.post("/api/coach/teams/:id/evaluation-requests", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const { phrase } = req.body;
  const team = db.prepare("SELECT * FROM teams WHERE id = ? AND coach_id = ?").get(req.params.id, req.user.id);

  if (!team) return res.status(404).json({ error: "Équipe introuvable." });

  const players = db.prepare("SELECT player_id FROM team_players WHERE team_id = ?").all(req.params.id);
  if (players.length === 0) {
    return res.status(400).json({ error: "Cette équipe n’a aucun joueur." });
  }

  const requestPhrase = phrase || "Évaluation des fondamentaux : Tir, Passe, Dribble, Défense et Physique.";
  const created = [];

  const tx = db.transaction(() => {
    const insert = db.prepare(`
      INSERT INTO evaluation_requests (id, coach_id, team_id, player_id, phrase, status, created_at, completed_at)
      VALUES (?, ?, ?, ?, ?, 'À faire', ?, NULL)
    `);

    for (const row of players) {
      const requestId = id();
      insert.run(requestId, req.user.id, team.id, row.player_id, requestPhrase, now());
      created.push(requestId);
    }
  });

  tx();

  res.status(201).json({ created });
});

app.get("/api/coach/evaluation-requests", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const rows = db.prepare(`
    SELECT er.*, p.name AS player_name, p.level AS player_level, t.name AS team_name
    FROM evaluation_requests er
    JOIN users p ON p.id = er.player_id
    LEFT JOIN teams t ON t.id = er.team_id
    WHERE er.coach_id = ?
    ORDER BY er.created_at DESC
  `).all(req.user.id);

  res.json({ requests: rows });
});

app.post("/api/coach/evaluation-requests/:id/evaluations", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  const request = db.prepare(`
    SELECT * FROM evaluation_requests WHERE id = ? AND coach_id = ?
  `).get(req.params.id, req.user.id);

  if (!request) return res.status(404).json({ error: "Demande introuvable." });
  if (request.status === "Terminée") return res.status(400).json({ error: "Cette demande est déjà terminée." });

  const { fundamentals, phrase } = req.body;
  if (!fundamentals || typeof fundamentals !== "object") {
    return res.status(400).json({ error: "Fondamentaux obligatoires." });
  }

  const evaluationId = id();
  const scale = 10;
  const allScores = [];

  const tx = db.transaction(() => {
    db.prepare(`
      INSERT INTO evaluations (
        id, request_id, coach_id, team_id, player_id, phrase, scale, global_average, score100, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?)
    `).run(
      evaluationId,
      request.id,
      request.coach_id,
      request.team_id,
      request.player_id,
      phrase || request.phrase || "",
      scale,
      now()
    );

    const insertFundamental = db.prepare(`
      INSERT INTO evaluation_fundamentals (id, evaluation_id, fundamental, comment, average)
      VALUES (?, ?, ?, ?, ?)
    `);

    const insertCriteria = db.prepare(`
      INSERT INTO evaluation_criteria (id, fundamental_id, criteria, score)
      VALUES (?, ?, ?, ?)
    `);

    for (const [fundamentalName, data] of Object.entries(fundamentals)) {
      const criteriaList = Array.isArray(data.criteria) ? data.criteria : [];
      const validScores = criteriaList
        .map(item => ({
          name: String(item.name || "").trim(),
          score: Number(item.score)
        }))
        .filter(item => item.name && item.score >= 1 && item.score <= 10);

      if (validScores.length === 0) continue;

      const average = validScores.reduce((sum, item) => sum + item.score, 0) / validScores.length;
      const fundamentalId = id();

      insertFundamental.run(
        fundamentalId,
        evaluationId,
        fundamentalName,
        data.comment || "",
        average
      );

      for (const item of validScores) {
        insertCriteria.run(id(), fundamentalId, item.name, item.score);
        allScores.push(item.score);
      }
    }

    if (allScores.length === 0) {
      throw new Error("Aucune note valide.");
    }

    const globalAverage = allScores.reduce((sum, score) => sum + score, 0) / allScores.length;
    const score100 = Math.round((globalAverage / 10) * 100);

    db.prepare(`
      UPDATE evaluations SET global_average = ?, score100 = ? WHERE id = ?
    `).run(globalAverage, score100, evaluationId);

    db.prepare(`
      UPDATE evaluation_requests SET status = 'Terminée', completed_at = ? WHERE id = ?
    `).run(now(), request.id);
  });

  try {
    tx();
  } catch (error) {
    return res.status(400).json({ error: error.message || "Évaluation impossible." });
  }

  res.status(201).json({ evaluation: getEvaluationById(evaluationId) });
});

app.get("/api/coach/evaluations", auth, requireRole("coach"), requireValidatedMember, (req, res) => {
  res.json({ evaluations: listEvaluations("WHERE e.coach_id = ?", [req.user.id]) });
});

app.get("/api/player/profile", auth, requireRole("player"), requireValidatedMember, (req, res) => {
  res.json({ user: safeUser(req.user) });
});

app.get("/api/player/evaluations", auth, requireRole("player"), requireValidatedMember, (req, res) => {
  res.json({ evaluations: listEvaluations("WHERE e.player_id = ?", [req.user.id]) });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Amical BRIANT Basket Club Coulogne démarré sur http://localhost:${PORT}`);
});
